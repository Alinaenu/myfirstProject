import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

public class HeapSortTest {

    private Main main;

    @BeforeEach
    public void setUp() throws Exception {
        main = new Main();
    }

    @Test
    public void testEquals() {
        int arr[] = { 20, 11, 13, 5, 6, 7 };
        List<Integer> list = Arrays.asList(5, 6, 7,11,13,20);
        assertEquals(list, main.heapSort(arr));
    }

    @Test
    public void testNotEquals() {
        int arr[] = { 20, 11, 13, 5, 6, 7 };
        List<Integer> list = Arrays.asList(5, 6, 7, 13, 11, 20);
        assertNotEquals(list,main.heapSort(arr));
    }


}
