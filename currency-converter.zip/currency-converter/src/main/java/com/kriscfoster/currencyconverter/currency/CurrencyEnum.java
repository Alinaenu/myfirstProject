package com.kriscfoster.currencyconverter.currency;

public enum CurrencyEnum {
    EUR,
    USD,
    GBP
}
