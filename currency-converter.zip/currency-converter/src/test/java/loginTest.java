

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest

public class loginTest {
    @Test
    public void test() throws Exception {

    }
}
